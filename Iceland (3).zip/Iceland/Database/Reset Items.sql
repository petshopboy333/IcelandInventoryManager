
update [tblInventoryItems]
set SellIn = 1, Quality = 1
where itemid = 1 

update [tblInventoryItems]
set SellIn = -1, Quality = 2
where itemid = 2

update [tblInventoryItems]
set SellIn = 9, Quality = 2
where itemid = 3

update [tblInventoryItems]
set SellIn = 2, Quality = 2
where itemid = 4

update [tblInventoryItems]
set SellIn = -1, Quality = 55
where itemid = 5

update [tblInventoryItems]
set SellIn = 2, Quality = 2
where itemid = 6

update [tblInventoryItems]
set SellIn = 2, Quality = 2
where itemid = 7

update [tblInventoryItems]
set SellIn = 2, Quality = 2
where itemid = 8

update [tblInventoryItems]
set SellIn = -1, Quality = 5
where itemid = 9