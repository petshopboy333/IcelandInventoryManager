﻿using InventoryManager.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InventoryManager.Controllers
{
    public class HomeController : Controller
    {
        private ItemContext db = new ItemContext();

        public int CheckQualityNegative(int quality)
        {
            if (quality < 0)
            {
                return 0;
            }
            else 
            {
                return quality;
            }
        }

        public int CheckQualityMoreThan50(int quality)
        {
            if (quality > 50)
            {
                return 50;
            }
            else
            {
                return quality;
            }
        }

        public void UpdateDatabase(Item item)
        {
            db.Database.ExecuteSqlCommand("UPDATE tblInventoryItems SET SellIn = {0}, Quality = {1} WHERE ItemID = {2}", item.sellIn, item.quality, item.itemID);
       
        }
        public ActionResult Index()
        {
            var items = db.Items;
            return View(items.ToList());
        }

        [HandleError]
        public ActionResult Process()
        {
            ViewBag.Message = "Your application description page.";

            int lastYear = DateTime.Now.Year - 1;

            var items = db.Items.ToList();
            List<Item> updateItems = new List<Item>();

            // Apply the rules to the items and update them 
            foreach (Item item in items)
            {
                // Adjust the sellin days (except for soap)
                if (item.itemName != "Soap")
                {
                    item.sellIn = item.sellIn - 1;
                }

                // Identify what the item is and adjust the quality
                switch (item.itemName)
                {
                    case "Aged Brie":
                        item.quality = CheckQualityMoreThan50(item.quality + 1);
                        break;

                    case "Frozen Item":
                        if (item.sellIn < 0)
                        {
                            item.quality = CheckQualityNegative(item.quality - 2);
                        }
                        else 
                        {
                            item.quality = CheckQualityNegative(item.quality - 1);
                        }
                        break;

                    case "Christmas Crackers":
                        // **** Assumption I made - Christmas Crackers will be restocked 3 months prior to Christmas this year ****

                        // Check if after Christmas last year
                        if (item.sellIn < 0)
                        {
                            item.quality = 0;
                        }
                        else if (item.sellIn > 5 && item.sellIn < 10)
                        {
                            item.quality = CheckQualityMoreThan50(item.quality + 2);
                        }
                        else if (item.sellIn <= 5)
                        {
                            item.quality = CheckQualityMoreThan50(item.quality + 3);
                        }
                        break;

                    case "Fresh Item":
                        if (item.sellIn < 0)
                        {
                            item.quality = CheckQualityNegative(item.quality - 4);
                        }
                        else
                        {
                            item.quality = CheckQualityNegative(item.quality - 2);
                        }
                        break;
                    case "INVALID ITEM":
                        item.itemName = "NO SUCH ITEM";
                        item.sellIn = 9999;
                        item.quality = 9999;
                        break;
                }

                UpdateDatabase(item);
                
                updateItems.Add(item);
            } 
            

            return View(updateItems);
        }


    }
}