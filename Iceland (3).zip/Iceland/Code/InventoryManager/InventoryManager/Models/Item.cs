﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;


namespace InventoryManager.Models
{
    [Table("tblInventoryItems")]

    public class Item
    {
        public int itemID { get; set; }
        public string itemName { get; set; }
        public int sellIn { get; set; }
        public int quality { get; set; }
    }
}