
Build: No special instructions, just build in Visual Studio

Test: 1. Update the items to their initial values using the script Reset Items.sql
      2. Run the application
      3. After clicking the button, the view will now show the items with their updated values 	

Query: based on the rules the first Frozen Item should have a quality of 53 not 50, the output appears to be incorrect?  